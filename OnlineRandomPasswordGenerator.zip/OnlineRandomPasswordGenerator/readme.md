To anticipate your passwords from being hacked by social building,
 brute constrain or word reference assault strategy, 
and keep your online accounts secure, you ought to take note that:
	1. Don't utilize the same watchword, security address 
and reply for numerous critical accounts.
	2. Utilize a secret word that has at slightest 16 characters, 
    utilize at slightest 
one number, one capitalized letter, one lowercase letter and one 
special symbol.
	3. Don't utilize the names of your families,
 friends or pets in your passwords.
	4. Don't utilize postcodes, house numbers, phone numbers, 
    birthdates, ID card numbers, 
social security numbers, and so on in your passwords.
	5. Don't utilize any lexicon word in your passwords. 
Cases of solid passwords: ePYHc~dS*)8$+V-' , qzRtC{6rXN3NRgL , 
zbfUMZPE6`FC%)sZ. Cases of frail passwords: 
qwert12345, Gbt3fC79ZmMEFUFJ, 1234567890, 987654321, nortonpassword.

We make a Online Random Generator for anyone who wants to have a 
unique strong password with easily to use and copy.
